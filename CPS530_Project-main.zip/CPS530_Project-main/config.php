<?php

$mysqli= new mysqli("localhost", "id15517579_cps530", "Mx[qCCB5Q5~>9=cj", "id15517579_seedsdbms");

if ($mysqli -> connect_errno){
  echo "Failed to connect to MYSQL" . $mysqli -> connect_error;
  exit();
}
?>
